const $ = (id) => document.getElementById(id);
const send = (message) => chrome.runtime.sendMessage(message);

function showServer(state) {
  const pill = $("server");
  pill.classList.toggle("bad", state.server !== "online" || !state.aiAnalysis);
  if (state.server === "waking") pill.textContent = "Server is waking up… (about 1 minute)";
  else if (state.server !== "online") pill.textContent = "Server unreachable";
  else if (!state.aiAnalysis) pill.textContent = "Server online · AI not configured (nothing will be hidden)";
  else pill.textContent = `AI fact-check active · ${state.aiModel}`;
}

// Firefox treats site access as opt-in: ask for it if the social sites are not granted yet.
const SITE_ORIGINS = chrome.runtime.getManifest().content_scripts.flatMap((script) => script.matches);
const IS_FIREFOX = typeof browser !== "undefined" && typeof browser.runtime?.getBrowserInfo === "function";
async function renderSiteAccess() {
  let granted = true; // Chrome/Edge grant the content-script sites at install time.
  if (IS_FIREFOX) {
    try { granted = await chrome.permissions.contains({ origins: SITE_ORIGINS }); } catch { granted = true; }
  }
  $("site-access").hidden = granted;
}
$("grant-sites").addEventListener("click", async () => {
  await chrome.permissions.request({ origins: SITE_ORIGINS }).catch(() => false);
  renderSiteAccess();
});

async function render() {
  renderSiteAccess();
  const state = await send({ type: "status" });
  showServer(state);
  $("signed-out").hidden = state.signedIn;
  $("signed-in").hidden = !state.signedIn;
  $("api-base").value = state.apiBase;
  if (state.signedIn) {
    $("user-name").textContent = state.user.full_name || state.user.email || state.user.phone || "you";
    $("enabled").checked = state.enabled;
    $("strict").checked = state.strict;
    $("hide-labeled").checked = state.hideLabeled !== false;
    $("stat-checked").textContent = state.stats.checked;
    $("stat-hidden").textContent = state.stats.hidden;
  }
  if (state.server === "waking") setTimeout(render, 10_000);
}

$("login-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const apiBase = $("api-base").value.trim();
  $("login-error").textContent = "";
  // Servers outside *.onrender.com / localhost need an extra permission.
  if (!/^https:\/\/[^/]+\.onrender\.com|^http:\/\/(localhost|127\.0\.0\.1)/.test(apiBase)) {
    const granted = await chrome.permissions.request({ origins: [`${new URL(apiBase).origin}/*`] });
    if (!granted) { $("login-error").textContent = "Permission to reach that server was denied."; return; }
  }
  $("login-button").disabled = true;
  $("login-button").textContent = "Signing in…";
  const result = await send({ type: "login", identity: $("identity").value.trim(), password: $("password").value, apiBase });
  $("login-button").disabled = false;
  $("login-button").textContent = "Sign in";
  $("password").value = "";
  if (!result.ok) { $("login-error").textContent = result.error; return; }
  render();
});

$("enabled").addEventListener("change", (e) => send({ type: "setOption", key: "enabled", value: e.target.checked }));
$("hide-labeled").addEventListener("change", (e) => send({ type: "setOption", key: "hideLabeled", value: e.target.checked }));
$("strict").addEventListener("change", (e) => send({ type: "setOption", key: "strict", value: e.target.checked }));
$("reset-stats").addEventListener("click", async () => { await send({ type: "resetStats" }); render(); });
$("logout").addEventListener("click", async () => { await send({ type: "logout" }); render(); });

render();
