// Content script: finds posts/videos in the feed, asks the background worker to check them,
// and removes the ones the server flags as fake or AI-generated.
(() => {
  const MIN_TEXT = 40;
  const MAX_TEXT = 2000;
  const BATCH_SIZE = 8;
  const RETRY_MS = 30_000;
  const host = location.hostname.replace(/^(www|m|web)\./, "");

  const text = (el) => (el ? (el.innerText || el.textContent || "").trim() : "");
  const attr = (el, name) => (el ? el.getAttribute(name) || "" : "");

  // Per-platform: which elements are posts, what text to send, and which element to remove.
  const PLATFORMS = {
    "youtube.com": {
      name: "YouTube",
      kind: "video",
      selector: [
        "ytd-rich-item-renderer", "ytd-video-renderer", "ytd-compact-video-renderer", "ytd-grid-video-renderer",
        "ytd-reel-item-renderer", "ytd-playlist-video-renderer", "ytm-shorts-lockup-view-model", "yt-lockup-view-model",
        // m.youtube.com (phones)
        "ytm-rich-item-renderer", "ytm-video-with-context-renderer", "ytm-compact-video-renderer",
        "ytm-reel-item-renderer", "ytm-video-card-renderer",
      ].join(", "),
      extract: (el) => {
        const title = el.querySelector("#video-title, #video-title-link, h3, .yt-lockup-metadata-view-model-wiz__title, .media-item-headline, .YtmCompactMediaItemHeadline, .shortsLockupViewModelHostOutsideMetadataTitle");
        const channel = el.querySelector("#channel-name, ytd-channel-name, .yt-content-metadata-view-model-wiz__metadata-text, .media-item-byline, .YtmBadgeAndBylineRendererItemByline");
        const description = el.querySelector("#description-text, .metadata-snippet-text");
        const titleText = attr(title, "title") || text(title) || attr(el.querySelector("a[aria-label]"), "aria-label");
        return [titleText, text(channel), text(description)].filter(Boolean).join("\n");
      },
      target: (el) => el,
    },
    "facebook.com": {
      name: "Facebook",
      kind: "post",
      selector: "div[aria-posinset], div[data-pagelet^='FeedUnit'], div[role='article']:not([role='article'] div[role='article']), div[data-tracking-duration-id], article",
      extract: (el) => text(el),
      target: (el) => el,
    },
    "instagram.com": {
      name: "Instagram",
      kind: "post",
      selector: "article",
      extract: (el) => text(el),
      target: (el) => el,
    },
    "x.com": {
      name: "X (Twitter)",
      kind: "post",
      selector: "article[data-testid='tweet']",
      extract: (el) => [
        text(el.querySelector("[data-testid='User-Name']")),
        text(el.querySelector("[data-testid='tweetText']")),
        text(el.querySelector("[data-testid='birdwatch-pivot']")), // Community Notes ("Readers added context")
      ].filter(Boolean).join("\n"),
      target: (el) => el.closest("[data-testid='cellInnerDiv']") || el,
    },
    "reddit.com": {
      name: "Reddit",
      kind: "post",
      selector: "shreddit-post, div.thing.link",
      extract: (el) => [attr(el, "post-title"), text(el)].filter(Boolean).join("\n"),
      target: (el) => el.closest("article") || el,
    },
    "linkedin.com": {
      name: "LinkedIn",
      kind: "post",
      selector: "div.feed-shared-update-v2, div[data-urn^='urn:li:activity']",
      extract: (el) => text(el),
      target: (el) => el,
    },
  };
  PLATFORMS["twitter.com"] = PLATFORMS["x.com"];
  PLATFORMS["mobile.twitter.com"] = PLATFORMS["x.com"];

  const platform = PLATFORMS[host];
  if (!platform) return;

  // Labels the platforms themselves put on AI-made or altered media. Only short, stand-alone
  // badge texts count, so a news post that merely talks *about* AI is not hidden.
  const AI_BADGE = /^(ai info|made with ai|ai[- ]generated( content)?|generated with ai|created with ai|altered or synthetic content|synthetic content|digitally (altered|created|generated)( content)?)$/i;
  const AI_HASHTAG = /(^|\s)#(ai(art|generated|video|videos|image|images|artwork|animation|influencer|model)|midjourney|stablediffusion|sora|veo3?|deepfake)\b/i;

  function platformAiLabel(el) {
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(), seen = 0; node && seen < 4000; node = walker.nextNode(), seen += 1) {
      const value = node.nodeValue.trim();
      if (value && value.length <= 40 && AI_BADGE.test(value)) return value;
    }
    for (const labelled of el.querySelectorAll("[aria-label]")) {
      const value = labelled.getAttribute("aria-label").trim();
      if (value.length <= 40 && AI_BADGE.test(value)) return value;
    }
    const tag = text(el).match(AI_HASHTAG);
    return tag ? `#${tag[2]}` : null;
  }

  let enabled = true;
  let strict = false;
  let hideLabeled = true;
  let signedIn = true;
  let nextId = 1;
  const queue = new Map(); // id -> { el, target, text }
  let flushing = false;

  function hash(value) {
    let h = 5381;
    for (let i = 0; i < value.length; i += 1) h = ((h << 5) + h + value.charCodeAt(i)) | 0;
    return String(h >>> 0);
  }

  function clean(value) {
    return value.replace(/\s+/g, " ").trim().slice(0, MAX_TEXT);
  }

  function nearViewport(el) {
    const rect = el.getBoundingClientRect();
    return rect.bottom > -window.innerHeight && rect.top < window.innerHeight * 3;
  }

  function resetElement(el) {
    const target = platform.target(el);
    target.classList.remove("vg-hidden", "vg-pending");
    delete el.dataset.vgState;
    delete el.dataset.vgKey;
  }

  function scan() {
    if (!enabled || !signedIn) return;
    for (const el of document.querySelectorAll(platform.selector)) {
      // Skip posts nested inside another matched post (comments, shared posts).
      const parent = el.parentElement && el.parentElement.closest(platform.selector);
      if (parent) continue;
      // Reading innerText forces layout, so only extract posts near the screen (a long feed has hundreds).
      if (!nearViewport(el)) continue;
      const content = clean(platform.extract(el));
      const key = hash(content);
      if (el.dataset.vgKey === key) continue; // already handled this exact content
      if (el.dataset.vgKey) resetElement(el); // element was recycled with new content (YouTube does this)
      if (content.length < MIN_TEXT) {
        if (content.length > 0) { el.dataset.vgKey = key; el.dataset.vgState = "skip"; }
        continue;
      }
      const label = hideLabeled ? platformAiLabel(el) : null;
      if (label) {
        el.dataset.vgKey = key;
        el.dataset.vgState = "hidden";
        platform.target(el).classList.add("vg-hidden");
        chrome.runtime.sendMessage({ type: "countLabeled" }).catch(() => {});
        continue;
      }
      const id = `vg${nextId++}`;
      el.dataset.vgKey = key;
      el.dataset.vgState = "pending";
      el.dataset.vgId = id;
      const target = platform.target(el);
      if (strict) target.classList.add("vg-pending");
      queue.set(id, { el, target, text: content, key });
    }
    checkWatchPage();
    flush();
  }

  // YouTube watch page: check the video that is playing, not just the recommendations.
  function checkWatchPage() {
    if (host !== "youtube.com" || location.pathname !== "/watch") return;
    const meta = document.querySelector("ytd-watch-metadata");
    if (!meta) return;
    const title = text(meta.querySelector("h1"));
    const description = text(meta.querySelector("#description-inline-expander, #description"));
    const content = clean(`${title}\n${description}`);
    const key = hash(location.search + content);
    if (content.length < MIN_TEXT || meta.dataset.vgKey === key) return;
    document.querySelector(".vg-watch-notice")?.remove();
    document.querySelector("#player")?.classList.remove("vg-hidden");
    meta.dataset.vgKey = key;
    const label = hideLabeled ? platformAiLabel(document.querySelector("ytd-watch-flexy") || meta) : null;
    if (label) {
      hideWatchVideo({ reason: `Labeled "${label}" by YouTube`, summary: "" });
      chrome.runtime.sendMessage({ type: "countLabeled" }).catch(() => {});
      return;
    }
    const id = `vg${nextId++}`;
    queue.set(id, { el: meta, target: meta, text: content, key, watch: true });
  }

  function applyResult(entry, result) {
    const { el, target } = entry;
    if (el.dataset.vgKey !== entry.key) return; // content changed while we waited
    if (result.status === "checked") {
      target.classList.remove("vg-pending");
      if (result.hide) {
        el.dataset.vgState = "hidden";
        if (entry.watch) hideWatchVideo(result);
        else target.classList.add("vg-hidden");
      } else {
        el.dataset.vgState = "ok";
      }
    } else if (["rate_limited", "error"].includes(result.status)) {
      target.classList.remove("vg-pending");
      el.dataset.vgState = "retry";
      setTimeout(() => { if (el.dataset.vgState === "retry") { delete el.dataset.vgKey; scan(); } }, RETRY_MS);
    } else {
      target.classList.remove("vg-pending");
      el.dataset.vgState = result.status || "ok";
    }
  }

  function hideWatchVideo(result) {
    const video = document.querySelector("video");
    if (video) video.pause();
    const player = document.querySelector("#player");
    player?.classList.add("vg-hidden");
    if (!document.querySelector(".vg-watch-notice")) {
      const notice = document.createElement("div");
      notice.className = "vg-watch-notice";
      notice.innerHTML = "<b>Hidden by Fake News Detector.</b> ";
      notice.append(document.createTextNode(`${result.reason}. ${result.summary || ""}`));
      (player?.parentElement || document.body).prepend(notice);
    }
  }

  async function flush() {
    if (flushing || !queue.size) return;
    flushing = true;
    try {
      while (queue.size && enabled) {
        const batch = [...queue.entries()].slice(0, BATCH_SIZE);
        batch.forEach(([id]) => queue.delete(id));
        let response;
        try {
          response = await chrome.runtime.sendMessage({
            type: "check",
            items: batch.map(([id, entry]) => ({ id, text: entry.text, platform: platform.name, kind: platform.kind })),
          });
        } catch {
          response = { retry: true }; // extension was reloaded or worker restarted
        }
        if (!response || response.disabled || response.signedOut) {
          if (response?.signedOut) signedIn = false;
          batch.forEach(([, entry]) => resetElement(entry.el));
          break;
        }
        if (response.retry) {
          batch.forEach(([, entry]) => applyResult(entry, { status: "error" }));
          break;
        }
        const byId = new Map(response.results.map((r) => [r.id, r]));
        batch.forEach(([id, entry]) => applyResult(entry, byId.get(id) || { status: "error" }));
      }
    } finally {
      flushing = false;
    }
  }

  function unhideAll() {
    document.querySelectorAll(".vg-hidden, .vg-pending").forEach((el) => el.classList.remove("vg-hidden", "vg-pending"));
    document.querySelectorAll("[data-vg-key]").forEach((el) => { delete el.dataset.vgKey; delete el.dataset.vgState; });
    document.querySelector(".vg-watch-notice")?.remove();
    queue.clear();
  }

  let timer = null;
  function scheduleScan() {
    if (timer) return;
    timer = setTimeout(() => { timer = null; scan(); }, 600);
  }

  chrome.storage.local.get(["enabled", "strict", "hideLabeled", "token"]).then((state) => {
    enabled = state.enabled !== false;
    strict = Boolean(state.strict);
    hideLabeled = state.hideLabeled !== false;
    signedIn = Boolean(state.token);
    scan();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.enabled) {
      enabled = changes.enabled.newValue !== false;
      if (!enabled) unhideAll();
    }
    if (changes.strict) strict = Boolean(changes.strict.newValue);
    if (changes.hideLabeled) {
      hideLabeled = changes.hideLabeled.newValue !== false;
      unhideAll();
    }
    if (changes.token) {
      signedIn = Boolean(changes.token.newValue);
      if (!signedIn) unhideAll();
    }
    scheduleScan();
  });

  new MutationObserver(scheduleScan).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener("scroll", scheduleScan, { passive: true });
})();
