# Fake News Detector – Feed Filter (Chrome, Edge, Firefox)

Sign in with your Fake News Detector account and the extension hides posts and videos
that the server's AI judges **likely fake** or **likely AI-generated** on Facebook,
Instagram, X (Twitter), YouTube, Reddit and LinkedIn.

## Install on a computer (Chrome / Edge)
1. Open `chrome://extensions` (or `edge://extensions`) and turn on **Developer mode**.
2. Click **Load unpacked** and select this `extension` folder.
3. Click the extension icon, sign in with your email/phone and password.

## Install on an Android phone (Firefox)
Stable Firefox only installs signed add-ons.
1. Zip this folder and upload it once at https://addons.mozilla.org/developers/addon/submit/distribution
   choosing **On your own** (free, automatic signing). Download the signed `.xpi`.
2. Firefox → Settings → About Firefox → tap the logo 5 times (enables the debug menu).
3. Settings → **Install add-on from file** → pick the `.xpi`.
4. Open the add-on, tap **Allow on social sites**, then sign in.

It only works in the browser versions of these sites (youtube.com, instagram.com, facebook.com, x.com),
not inside their phone apps.

The default server is `https://veriguard-backend-1t79.onrender.com`; change it under
**Server** in the popup if your backend URL is different.

## How it works
- `content.js` finds posts near the screen, sends their text to `background.js`.
- `background.js` calls `POST /api/extension/check` with your session token
  (`Authorization: Bearer …`, obtained from `POST /api/extension/login`).
- Posts the platform itself labels as AI-made ("AI info", "Made with AI", "Altered or synthetic content",
  hashtags such as `#aiart`) are hidden immediately, without a server call (toggle: **Hide AI-labeled media**).
- Posts with `hide: true` are removed with `display: none`. **Strict mode** keeps
  posts invisible until they have been checked.
- Results are cached on the server and in the extension; feed checks are not saved in your history.

## Limits
- Videos are judged from their title, channel, description and platform AI labels, not their frames.
- When the AI provider is not configured or fails, only platform-labeled AI content is hidden.
- Free Render instances sleep; the first checks after a pause may take about a minute.

## Privacy

While the filter is on and you are signed in, the text of posts near the visible part of the page (title, caption, author name) is sent to the Fake News Detector server you signed in to, and from there to its AI provider, so it can be checked. Results are cached on the server without your account details. Nothing is sent while the filter is off or you are signed out.
