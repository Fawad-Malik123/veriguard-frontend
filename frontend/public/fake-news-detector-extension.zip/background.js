// Service worker: holds the session token and talks to the Fake News Detector API.
const DEFAULT_API = "https://veriguard-backend-1t79.onrender.com";
const DEFAULTS = { apiBase: DEFAULT_API, token: null, user: null, enabled: true, strict: false, hideLabeled: true, stats: { checked: 0, hidden: 0 } };
const resultCache = new Map(); // text -> result, so scrolling back does not re-check
const CACHE_LIMIT = 3000;

async function getState() {
  const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...stored };
}

function apiUrl(base, path) {
  return `${(base || DEFAULT_API).replace(/\/+$/, "")}${path}`;
}

async function request(path, { method = "GET", body, token, apiBase, timeoutMs = 12_000 } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  let response;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    response = await fetch(apiUrl(apiBase, path), { method, headers, body: body ? JSON.stringify(body) : undefined, signal: controller.signal });
  } catch (error) {
    // A sleeping free-tier server can take a minute to answer: report it as "waking up", not "offline".
    if (error?.name === "AbortError") return { ok: false, status: 504, data: { detail: "The server is waking up (free hosting). Wait about a minute and try again." } };
    return { ok: false, status: 0, data: { detail: "Cannot reach the server. Check your internet connection." } };
  } finally {
    clearTimeout(timer);
  }
  const data = await response.json().catch(() => ({}));
  return { ok: response.ok, status: response.status, data };
}

function errorText(result) {
  if ([502, 503, 504].includes(result.status)) return "The server is waking up (free hosting). Wait about a minute and try again.";
  const detail = result.data?.detail;
  if (Array.isArray(detail)) return detail.map((item) => item.msg).join(" ");
  return detail || `Request failed (${result.status}).`;
}

let statsChain = Promise.resolve();
function bumpStats(checked, hidden) {
  if (!checked && !hidden) return statsChain;
  // Chain the read-modify-write so concurrent tabs don't overwrite each other's counts.
  statsChain = statsChain.then(async () => {
    const { stats } = await getState();
    await chrome.storage.local.set({ stats: { checked: stats.checked + checked, hidden: stats.hidden + hidden } });
  }).catch(() => {});
  return statsChain;
}

async function login({ identity, password, apiBase }) {
  const base = (apiBase || DEFAULT_API).trim();
  const result = await request("/api/extension/login", { method: "POST", body: { identity, password }, apiBase: base, timeoutMs: 75_000 });
  if (!result.ok) return { ok: false, error: errorText(result) };
  await chrome.storage.local.set({ apiBase: base, token: result.data.token, user: result.data.user });
  resultCache.clear();
  return { ok: true, user: result.data.user };
}

async function logout() {
  const state = await getState();
  if (state.token) await request("/api/extension/logout", { method: "POST", token: state.token, apiBase: state.apiBase });
  await chrome.storage.local.set({ token: null, user: null });
  resultCache.clear();
  return { ok: true };
}

async function status() {
  const state = await getState();
  const health = await request("/api/health", { apiBase: state.apiBase });
  let user = state.user;
  if (state.token && health.ok) {
    const me = await request("/api/auth/me", { token: state.token, apiBase: state.apiBase });
    if (me.ok && !me.data.user) {
      await chrome.storage.local.set({ token: null, user: null }); // session expired or account removed
      user = null;
    } else if (me.ok) {
      user = me.data.user;
    }
  }
  return {
    signedIn: Boolean(state.token && user),
    user,
    enabled: state.enabled,
    strict: state.strict,
    hideLabeled: state.hideLabeled,
    stats: state.stats,
    apiBase: state.apiBase,
    server: health.ok ? "online" : [502, 503, 504].includes(health.status) ? "waking" : "offline",
    aiAnalysis: Boolean(health.data?.ai_analysis),
    aiModel: health.data?.ai_model || null,
  };
}

async function check(items) {
  const state = await getState();
  if (!state.enabled) return { disabled: true };
  if (!state.token) return { signedOut: true };

  const results = [];
  const pending = [];
  for (const item of items) {
    const cached = resultCache.get(item.text);
    if (cached) results.push({ ...cached, id: item.id });
    else pending.push(item);
  }
  if (pending.length) {
    const response = await request("/api/extension/check", {
      method: "POST", token: state.token, apiBase: state.apiBase, body: { items: pending }, timeoutMs: 150_000,
    });
    if (response.status === 401) {
      await chrome.storage.local.set({ token: null, user: null });
      return { signedOut: true };
    }
    if (!response.ok) return { retry: true, error: errorText(response) };
    const byId = new Map(pending.map((item) => [item.id, item]));
    for (const result of response.data.results || []) {
      results.push(result);
      const source = byId.get(result.id);
      if (source && result.status === "checked") {
        resultCache.set(source.text, result);
        if (resultCache.size > CACHE_LIMIT) resultCache.delete(resultCache.keys().next().value);
      }
    }
    const checked = (response.data.results || []).filter((r) => r.status === "checked");
    await bumpStats(checked.length, checked.filter((r) => r.hide).length);
  }
  return { results, strict: state.strict };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const handlers = {
    login: () => login(message),
    logout: () => logout(),
    status: () => status(),
    check: () => check(message.items || []),
    setOption: async () => { await chrome.storage.local.set({ [message.key]: message.value }); return { ok: true }; },
    countLabeled: async () => { await bumpStats(1, 1); return { ok: true }; },
    resetStats: async () => { await chrome.storage.local.set({ stats: { checked: 0, hidden: 0 } }); return { ok: true }; },
  };
  const handler = handlers[message?.type];
  if (!handler) return false;
  handler().then(sendResponse, (error) => sendResponse({ ok: false, error: String(error?.message || error) }));
  return true; // keep the channel open for the async response
});
